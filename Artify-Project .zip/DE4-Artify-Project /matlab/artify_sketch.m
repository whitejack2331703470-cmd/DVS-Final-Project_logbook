function out = artify_sketch(img, colorBW, nSeeds, edgeThresh, lineStrength)
% ARTIFY_SKETCH  Style 3: Pencil sketch effect.
%   Edge-based, grayscale lines on light background.
%
%   Pipeline: Mean-Shift color quant → Grayscale → Edge (Canny) → Invert
%
%   Course: Lab3 (edge), Lab5 (Mean-Shift)
%
%   Inputs:
%     img           - RGB image
%     colorBW       - Mean-Shift bandwidth (default 0.06)
%     nSeeds        - Mean-Shift seeds (default 300)
%     edgeThresh    - Canny threshold (default 0.15)
%     lineStrength  - Line darkness 0-1 (default 0.9)

if nargin < 5, lineStrength = 0.9; end
if nargin < 4, edgeThresh = 0.15; end
if nargin < 3, nSeeds = 300; end
if nargin < 2, colorBW = 0.06; end

if ischar(img) || isstring(img), img = imread(img); end
if size(img, 3) == 1, img = repmat(img, [1 1 3]); end
img = im2double(img);

%% Mean-Shift color quantization (Lab5 - required)
[quantized, ~] = meanShiftColorQuant(img, colorBW, nSeeds);

%% Grayscale (Lab2)
gray = rgb2gray(quantized);

%% Edge detection (Lab3/Lab5)
edges = edge(gray, 'Canny', edgeThresh);

%% Sketch: white paper + dark lines
out = 1 - double(edges) * lineStrength;  % Invert: edges = dark
out = repmat(out, [1 1 3]);  % RGB for display
out = max(0, min(1, out));
end
