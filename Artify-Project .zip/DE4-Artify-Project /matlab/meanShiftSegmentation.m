function [segmented, labels] = meanShiftSegmentation(img, spatialBandwidth, colorBandwidth, maxIter)
% MEANSHIFTSEGMENTATION  Mean-Shift segmentation in (R,G,B,x,y) feature space.
%   Used for Style A: Oil Painting / Cartoon effect.
%   Implements mode-seeking: each pixel converges to a local mode (cluster center).
%
%   Inputs:
%     img              - RGB image [0,1] or uint8
%     spatialBandwidth - Spatial radius (pixels), controls region size
%     colorBandwidth   - Color radius [0,1], controls color merging
%     maxIter          - Max Mean-Shift iterations per point
%
%   Outputs:
%     segmented - Image with each region filled by mean color
%     labels    - Label map (same size as img, integer labels)

if nargin < 4, maxIter = 10; end
if nargin < 3, colorBandwidth = 0.15; end
if nargin < 2, spatialBandwidth = 15; end

% Normalize to [0,1]
if isa(img, 'uint8'), img = double(img) / 255; end
[h_orig, w_orig, ~] = size(img);
h = h_orig; w = w_orig;

% Downsample for speed (Mean-Shift is O(n^2) per pixel)
scale = 1;
if h * w > 100000
    scale = sqrt(100000 / (h * w));
    img = imresize(img, scale);
    [h, w, ~] = size(img);
end

% Build feature vectors: [R, G, B, x, y] - normalized
% Spatial coords normalized by spatialBandwidth so we can use single bandwidth
[X, Y] = meshgrid(1:w, 1:h);
features = zeros(h * w, 5);
features(:, 1:3) = reshape(img, h * w, 3);
features(:, 4) = reshape(X, h * w, 1) / spatialBandwidth;
features(:, 5) = reshape(Y, h * w, 1) / spatialBandwidth;

% Color scale: normalize so colorBandwidth is comparable
colorScale = 1 / colorBandwidth;
features(:, 1:3) = features(:, 1:3) * colorScale;

% Run Mean-Shift on a grid of seeds (accelerated)
% Sample every step pixels to get seed points
step = max(2, round(sqrt(h * w / 2000)));
[yy, xx] = meshgrid(1:step:h, 1:step:w);  % yy=row, xx=col
seeds = [yy(:), xx(:)];
seeds = seeds(seeds(:,1) <= h & seeds(:,2) <= w, :);
nSeeds = size(seeds, 1);

% Bandwidth for kernel (Euclidean in 5D)
h_bw = 1.0;  % In normalized feature space

modes = zeros(nSeeds, 5);
hWait = waitbar(0, 'Mean-Shift segmentation...', 'Name', 'Processing');
for i = 1:nSeeds
    r = seeds(i, 1); c = seeds(i, 2);
    idx = (c - 1) * h + r;  % column-major index
    pt = features(idx, :);
    
    for iter = 1:maxIter
        % Find points within bandwidth (spatial + color)
        dist = sum((features - pt) .^ 2, 2);
        inWindow = dist < h_bw^2;
        if sum(inWindow) < 2, break; end
        
        ptsIn = features(inWindow, :);
        newPt = mean(ptsIn, 1);
        if norm(newPt - pt) < 1e-4, break; end
        pt = newPt;
    end
    modes(i, :) = pt;
    waitbar(i / nSeeds, hWait);
end
close(hWait);

% Assign each pixel to nearest mode (avoid pdist2 for compatibility)
D = zeros(h * w, nSeeds);
hWait = waitbar(0, 'Assigning pixels to regions...', 'Name', 'Processing');
for i = 1:nSeeds
    D(:, i) = sum((features - modes(i, :)) .^ 2, 2);
    waitbar(i / nSeeds, hWait);
end
close(hWait);
[~, labels] = min(D, [], 2);

% Merge very similar modes (optional - reduce label count)
% For now keep labels as is

% Compute mean color per region
nLabels = max(labels);
meanColors = zeros(nLabels, 3);
imgFlat = reshape(img, h * w, 3);
for L = 1:nLabels
    mask = labels == L;
    if sum(mask) > 0
        meanColors(L, :) = mean(imgFlat(mask, :), 1);
    end
end

% Build output
segmented = reshape(meanColors(labels, :), h, w, 3);

% Resize back to exact original dimensions if we downsampled
if scale < 1
    segmented = imresize(segmented, [h_orig w_orig]);
    labels = imresize(reshape(labels, h, w), [h_orig w_orig], 'nearest');
    labels = labels(:);
end

segmented = max(0, min(1, segmented));

end
