function C = lxy_cartoon(A, w, sigma, quant_levels)
% LXY_CARTOON Image abstraction using bilateral filtering (from lxy project).
%    C = lxy_cartoon(A) or lxy_cartoon(A, w, sigma, quant_levels)
%    Modifies the color image A to have a cartoon-like appearance.
%    Based on: Winnemoller et al., Real-Time Video Abstraction, SIGGRAPH 2006.

if nargin < 4, quant_levels = 8; end
if nargin < 3, sigma = [3 0.1]; end
if nargin < 2, w = 5; end

% Default params
max_gradient      = 0.2;
sharpness_levels  = [3 14];
min_edge_strength = 0.3;

if ~exist('A','var') || isempty(A)
   error('Input image A is undefined or invalid.');
end
if ~isfloat(A) || size(A,3) ~= 3 || min(A(:)) < 0 || max(A(:)) > 1
   error('Input image A must be double NxMx3 in [0,1].');
end

B = bfilter2(A, w, sigma);

if exist('applycform','file')
   B = applycform(B,makecform('srgb2lab'));
else
   B = colorspace('Lab<-RGB',B);
end

[GX,GY] = gradient(B(:,:,1)/100);
G = sqrt(GX.^2+GY.^2);
G(G>max_gradient) = max_gradient;
G = G/max_gradient;

E = G; E(E<min_edge_strength) = 0;
S = diff(sharpness_levels)*G+sharpness_levels(1);

qB = B; dq = 100/(quant_levels-1);
qB(:,:,1) = (1/dq)*qB(:,:,1);
qB(:,:,1) = dq*round(qB(:,:,1));
qB(:,:,1) = qB(:,:,1)+(dq/2)*tanh(S.*(B(:,:,1)-qB(:,:,1)));

if exist('applycform','file')
   Q = applycform(qB,makecform('lab2srgb'));
else
   Q = colorspace('RGB<-Lab',qB);
end

C = repmat(1-E,[1 1 3]).*Q;
