function out = artify_watercolor(img, seSize, beta, edgeGain, wobbleScale)
% ARTIFY_WATERCOLOR  Watercolor effect from lxy project.
%   Pigment density variation, edge darkening, paper wobbling.
%
%   Inputs:
%     img        - RGB image (path or matrix)
%     seSize     - Morphological closing disk size (default 5)
%     beta       - Pigment density scaling (default 0.4)
%     edgeGain   - Edge darkening strength (default 0.5)
%     wobbleScale- Paper wobble amplitude (default 2)

if nargin < 5, wobbleScale = 2; end
if nargin < 4, edgeGain = 0.5; end
if nargin < 3, beta = 0.4; end
if nargin < 2, seSize = 5; end

if ischar(img) || isstring(img), img = imread(img); end
if size(img, 3) == 1, img = repmat(img, [1 1 3]); end
img = im2double(img);
if size(img, 3) == 4, img = img(:,:,1:3); end

% Abstraction: cartoon + morphological closing
abstract_img = imclose(lxy_cartoon(img), strel('disk', round(seSize)));

[h, w, ~] = size(img);

% Pigment density variation (Perlin-like texture)
T_low = imresize(imgaussfilt(rand(round(h/10), round(w/10)), 1), [h, w]);
T_high = imgaussfilt(rand(h, w), 1);
T = (T_low + T_high) / 2;
d = 1 + beta * (T - 0.5);

% Core formula: C' = C - (C - C^2)(d - 1)
watercolor_base = abstract_img - (abstract_img - abstract_img.^2) .* (d - 1);

% Edge darkening
gray_abstract = rgb2gray(abstract_img);
[Gmag, ~] = imgradient(gray_abstract);
Gmag = Gmag / max(Gmag(:) + eps);
edge_d = 1 + edgeGain * Gmag;
for c = 1:3
    watercolor_base(:,:,c) = watercolor_base(:,:,c) - ...
        (watercolor_base(:,:,c) - watercolor_base(:,:,c).^2) .* (edge_d - 1);
end

% Wobbling (paper grain effect)
[X, Y] = meshgrid(1:w, 1:h);
rng(42);  % Reproducible wobble
distort_X = X + (rand(h, w) - 0.5) * wobbleScale;
distort_Y = Y + (rand(h, w) - 0.5) * wobbleScale;
out = zeros(size(img));
for c = 1:3
    out(:,:,c) = interp2(X, Y, watercolor_base(:,:,c), distort_X, distort_Y, 'linear', 0.5);
end

out = max(0, min(1, out));

end
