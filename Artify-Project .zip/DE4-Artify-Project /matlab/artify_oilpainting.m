function out = artify_oilpainting(img, gradSigma, medianSize, blendRatio)
% ARTIFY_OILPAINTING  Oil painting / watershed style from lxy project.
%   Watershed segmentation + region averaging for painterly look.
%
%   Inputs:
%     img        - RGB image (path or matrix)
%     gradSigma  - Gaussian sigma for gradient refinement (default 4)
%     medianSize - Median filter size for edge softening (default 7)
%     blendRatio - Paint:original blend (0-1, default 0.7 = 70% paint)

if nargin < 4, blendRatio = 0.7; end
if nargin < 3, medianSize = 7; end
if nargin < 2, gradSigma = 4; end

if ischar(img) || isstring(img), img = imread(img); end
if size(img, 3) == 1, img = repmat(img, [1 1 3]); end
img = im2double(img);
if size(img, 3) == 4, img = img(:,:,1:3); end

% Cartoon abstraction
abstract_img = lxy_cartoon(img);
gray_abstract = rgb2gray(abstract_img);
grad = imgradient(gray_abstract);
grad_refined = imgaussfilt(grad, gradSigma);
L = watershed(grad_refined);

% Region averaging
watercolor_art = zeros(size(img));
stats = regionprops(L, 'PixelIdxList');
for k = 1:numel(stats)
    idx = stats(k).PixelIdxList;
    if ~isempty(idx)
        for c = 1:3
            channel_data = img(:,:,c);
            avg_color = mean(channel_data(idx));
            res_channel = watercolor_art(:,:,c);
            res_channel(idx) = avg_color;
            watercolor_art(:,:,c) = res_channel;
        end
    end
end

% Soften edges
for c = 1:3
    watercolor_art(:,:,c) = medfilt2(watercolor_art(:,:,c), [medianSize medianSize]);
end

% Blend with original
out = watercolor_art * blendRatio + img * (1 - blendRatio);
out = max(0, min(1, out));

end
