function [quantized, labels] = meanShiftColorQuant(img, colorBandwidth, nSeeds, maxIter)
% MEANSHIFTCOLORQUANT  Mean-Shift color quantization in RGB space only.
%   Used for Style B: Watercolor / Poster effect.
%   Finds color modes via Mean-Shift, assigns each pixel to nearest mode.
%
%   Inputs:
%     img             - RGB image [0,1] or uint8
%     colorBandwidth  - Bandwidth in color space [0,1], controls # of colors
%     nSeeds          - Number of seed points for Mean-Shift (default 500)
%     maxIter         - Max iterations per seed (default 15)
%
%   Outputs:
%     quantized - Image with colors reduced to mode values
%     labels    - Label map (index into color modes)

if nargin < 4, maxIter = 15; end
if nargin < 3, nSeeds = 500; end
if nargin < 2, colorBandwidth = 0.12; end

% Normalize to [0,1]
if isa(img, 'uint8'), img = double(img) / 255; end
[h, w, ~] = size(img);

% Reshape to Nx3
pixels = reshape(img, h * w, 3);
nPixels = size(pixels, 1);

% Subsample for speed if image is large
if nPixels > 50000
    idxSample = randperm(nPixels, 50000);
    pixelsFull = pixels;
    pixels = pixels(idxSample, :);
end

% Initialize seeds: random pixels or k-means init
rng(42);
seedIdx = randperm(size(pixels, 1), min(nSeeds, size(pixels, 1)));
seeds = pixels(seedIdx, :);

% Bandwidth squared (for Euclidean distance)
h_sq = colorBandwidth ^ 2;

% Mean-Shift: each seed converges to a mode
modes = zeros(size(seeds));
nSeedsTotal = size(seeds, 1);
hWait = waitbar(0, 'Mean-Shift color quantization...', 'Name', 'Processing');
for i = 1:nSeedsTotal
    pt = seeds(i, :);
    for iter = 1:maxIter
        % Points within bandwidth (Gaussian kernel / uniform)
        dist = sum((pixels - pt) .^ 2, 2);
        inWindow = dist < h_sq;
        if sum(inWindow) < 2, break; end
        
        ptsIn = pixels(inWindow, :);
        newPt = mean(ptsIn, 1);
        if norm(newPt - pt) < 1e-5, break; end
        pt = newPt;
    end
    modes(i, :) = pt;
    waitbar(i / nSeedsTotal, hWait);
end
close(hWait);

% Merge duplicate modes (modes that converged to same point)
uniqueModes = modes(1, :);
for i = 2:size(modes, 1)
    d = min(sum((uniqueModes - modes(i, :)) .^ 2, 2));
    if d > h_sq * 0.25  % Only add if sufficiently different
        uniqueModes = [uniqueModes; modes(i, :)];  %#ok<AGROW>
    end
end
modes = uniqueModes;

% Assign ALL pixels to nearest mode (use full pixel set)
if exist('pixelsFull', 'var')
    pixels = pixelsFull;
end
D = zeros(size(pixels, 1), size(modes, 1));
nModes = size(modes, 1);
hWait = waitbar(0, 'Assigning pixels to modes...', 'Name', 'Processing');
for i = 1:nModes
    D(:, i) = sum((pixels - modes(i, :)) .^ 2, 2);
    waitbar(i / nModes, hWait);
end
close(hWait);
[~, labels] = min(D, [], 2);

% Build output
quantized = modes(labels, :);
quantized = reshape(quantized, h, w, 3);
quantized = max(0, min(1, quantized));

end
