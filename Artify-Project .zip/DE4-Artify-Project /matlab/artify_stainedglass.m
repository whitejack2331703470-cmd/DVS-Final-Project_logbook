function out = artify_stainedglass(img, k, saturationBoost, addCanvas)
% ARTIFY_STAINEDGLASS  Floral stained glass style - jewel-tone k-means + lead lines.
%   Based on floral stained glass reference: k-means segmentation, glass palette
%   remapping, black lead lines, optional mosaic canvas with gothic arch frame.
%
%   Inputs:
%     img            - RGB image (path or matrix, double [0,1])
%     k              - Number of k-means segments (4-12, default 6)
%     saturationBoost - Pre-segmentation saturation boost (1.5-3, default 2.2)
%     addCanvas      - If true, add mosaic border + gothic frame (default false)

if nargin < 4, addCanvas = false; end
if nargin < 3, saturationBoost = 2.2; end
if nargin < 2, k = 6; end

if ischar(img) || isstring(img), img = imread(img); end
if size(img, 3) == 1, img = repmat(img, [1 1 3]); end
img = im2double(img);
if size(img, 3) == 4, img = img(:,:,1:3); end

f = im2uint8(img);
[imgH, imgW, ~] = size(f);

% Scale structural elements by image size (reference ~600px)
scale = min(imgH, imgW) / 500;
scale = max(0.5, min(2, scale));

%% Step 1: Pre-smooth + saturation boost for k-means input
f_smooth = imgaussfilt(f, 2.0);
f_hsv = rgb2hsv(f_smooth);
f_hsv(:,:,2) = min(f_hsv(:,:,2) * saturationBoost, 1);
f_boosted = hsv2rgb(f_hsv);

%% Step 2: k-means segmentation
k = max(4, min(12, round(k)));
[L, centers] = imsegkmeans(im2uint8(f_boosted), k);

%% Step 3: Remap cluster colors to jewel-tone glass palette
glassColors = [
    0.95, 0.90, 0.20;   % Bright golden yellow
    0.05, 0.35, 0.80;   % Deep cobalt blue
    0.85, 0.08, 0.12;   % Vivid ruby red
    0.08, 0.60, 0.20;   % Emerald green
    0.92, 0.45, 0.05;   % Amber orange
    0.70, 0.05, 0.55;   % Deep magenta
    0.98, 0.97, 0.88;   % Warm white
    0.05, 0.65, 0.75;   % Teal
    0.90, 0.75, 0.10;   % Rich gold
    0.35, 0.05, 0.70;   % Royal purple
];

centers_norm = double(centers) / 255;
centers_lab  = rgb2lab(reshape(centers_norm, [k,1,3]));
glass_lab    = rgb2lab(reshape(glassColors,  [size(glassColors,1),1,3]));

remappedColors = zeros(k, 3);
for ci = 1:k
    c_lab = squeeze(centers_lab(ci,1,:))';
    diffs = squeeze(glass_lab(:,1,:)) - repmat(c_lab, size(glassColors,1), 1);
    [~, bestIdx] = min(sum(diffs.^2, 2));
    remappedColors(ci,:) = glassColors(bestIdx,:);
end

%% Step 4: Build color blocks and apply backlit stained-glass look
J = zeros(imgH, imgW, 3);
for ci = 1:k
    m = (L == ci);
    for ch = 1:3
        p = J(:,:,ch);
        p(m) = remappedColors(ci,ch);
        J(:,:,ch) = p;
    end
end

J_smooth = imgaussfilt(J, 1.5);
HSV = rgb2hsv(J_smooth);
HSV(:,:,2) = min(HSV(:,:,2)*1.3 + 0.15, 1);
HSV(:,:,3) = min((HSV(:,:,3).^0.65)*1.05, 1);
J_style = hsv2rgb(HSV);
J_bloom = imgaussfilt(J_style, 5.0);
J_style = min(J_style*0.88 + J_bloom*0.22, 1);

%% Step 5: Build lead-line mask for main figures
r15 = max(2, round(15*scale)); r12 = max(2, round(12*scale));
r8 = max(1, round(8*scale)); r6 = max(1, round(6*scale));
r3 = max(1, round(3*scale)); minArea = max(300, round(1500*scale*scale));

leadMask = false(imgH, imgW);
for label = 1:k
    mask = (L == label);
    mask = imclose(mask, strel('disk', r15));
    mask = imopen(mask,  strel('disk', r12));
    mask = imfill(mask,  'holes');
    mask = bwareaopen(mask, minArea);

    B = bwboundaries(mask, 'noholes');
    for i = 1:length(B)
        boundary = B{i};
        if size(boundary,1) < max(100, round(300*scale))
            continue;
        end
        r = boundary(:,1);
        c = boundary(:,2);
        pad = min(80, floor(length(r)/3));
        if pad < 20, continue; end
        r_pad = [r(end-pad+1:end); r; r(1:pad)];
        c_pad = [c(end-pad+1:end); c; c(1:pad)];
        r_pad = smoothdata(r_pad, 'gaussian', min(121, 2*floor(length(r_pad)/4)+1));
        c_pad = smoothdata(c_pad, 'gaussian', min(121, 2*floor(length(c_pad)/4)+1));
        r_s = r_pad(pad+1:end-pad);
        c_s = c_pad(pad+1:end-pad);
        t  = 1:length(r_s);
        tq = linspace(1, length(r_s), length(r_s)*6);
        r_q = min(max(interp1(t, r_s, tq, 'spline'), 1), imgH);
        c_q = min(max(interp1(t, c_s, tq, 'spline'), 1), imgW);
        poly = poly2mask(c_q, r_q, imgH, imgW);
        band = imdilate(poly, strel('disk', r8)) & ~imerode(poly, strel('disk', r6));
        leadMask = leadMask | band;
    end
end

leadMask = imclose(leadMask, strel('disk', r8));
leadMask = bwmorph(leadMask, 'bridge', Inf);
leadMask = imdilate(leadMask, strel('disk', r3));
lms = imgaussfilt(double(leadMask), 4.5);
leadMaskFinal = lms > 0.25;
leadMaskFinal = bwareaopen(leadMaskFinal, max(100, round(300*scale)));
leadMaskFinal = imclose(leadMaskFinal, strel('disk', r6));

%% Step 6: Add grid-like lead lines to background
HSV0 = rgb2hsv(J_style);
H = HSV0(:,:,1); S = HSV0(:,:,2); V = HSV0(:,:,3);
bgMask = (H > 0.10 & H < 0.19) & (S > 0.20) & (V > 0.45);
subjectMask = false(imgH, imgW);
subjectMask(round(imgH*0.18):imgH, round(imgW*0.18):round(imgW*0.82)) = true;
bgMask = bgMask & ~subjectMask;
bgMask = imopen(bgMask, strel('disk', max(2, round(8*scale))));
bgMask = imclose(bgMask, strel('disk', max(5, round(20*scale))));
bgMask = imfill(bgMask, 'holes');
bgMask = bwareaopen(bgMask, max(500, round(3000*scale*scale)));

bgGridMask = false(imgH, imgW);
xPos = round(linspace(1, imgW, 7));
xPos = xPos + round(randn(size(xPos)) * imgW * 0.02);
xPos = min(max(xPos, 10), imgW-10);
for i = 1:length(xPos)
    x = xPos(i);
    curve = round(15 * sin(linspace(0, 2*pi, imgH))' + 8 * randn(imgH,1));
    for y = 1:imgH
        xx = x + curve(y);
        if xx >= 1 && xx <= imgW
            bgGridMask(y, max(1,xx-1):min(imgW,xx+1)) = true;
        end
    end
end
yPos = round(linspace(1, imgH, 8));
yPos = yPos + round(randn(size(yPos)) * imgH * 0.02);
yPos = min(max(yPos, 10), imgH-10);
for i = 1:length(yPos)
    y = yPos(i);
    curve = round(15 * sin(linspace(0, 2*pi, imgW)) + 8 * randn(1,imgW));
    for x = 1:imgW
        yy = y + curve(x);
        if yy >= 1 && yy <= imgH
            bgGridMask(max(1,yy-1):min(imgH,yy+1), x) = true;
        end
    end
end
bgGridMask = bgGridMask & bgMask;
bgGridMask = imdilate(bgGridMask, strel('disk', 2));
bgGridMask = imclose(bgGridMask, strel('disk', 2));
bgGridSoft = imgaussfilt(double(bgGridMask), 1.0) > 0.12;

%% Step 7: Combine lead lines
allLeadMask = leadMaskFinal | bgGridSoft;
leadColor = [0.03, 0.02, 0.02];
J_art = J_style;
for ch = 1:3
    p = J_art(:,:,ch);
    p(allLeadMask) = leadColor(ch);
    J_art(:,:,ch) = p;
end

%% Output: core stained glass (same size as input)
out = max(0, min(1, J_art));

if ~addCanvas
    return;
end

%% Optional: Canvas with mosaic border + gothic frame
marginX = round(imgW * 0.25);
marginY = round(imgH * 0.18);
canvW = imgW + 2*marginX;
canvH = imgH + 2*marginY;
tileW = round(canvW / 18);
tileH = round(tileW * 0.9);
leadW = max(2, round(tileW * 0.06));

mosaicPalette = [
    0.95, 0.88, 0.15; 0.05, 0.30, 0.82; 0.85, 0.10, 0.10;
    0.08, 0.55, 0.18; 0.92, 0.42, 0.04; 0.60, 0.04, 0.50;
    0.04, 0.60, 0.72; 0.88, 0.70, 0.08; 0.96, 0.50, 0.60; 0.30, 0.04, 0.68;
];
rng(42);
canvas = zeros(canvH, canvW, 3);
nTilesX = ceil(canvW / tileW) + 1;
nTilesY = ceil(canvH / tileH) + 1;
for ty = 0:nTilesY-1
    for tx = 0:nTilesX-1
        r1 = ty*tileH + 1;  r2 = min(r1+tileH-1, canvH);
        c1 = tx*tileW + 1;  c2 = min(c1+tileW-1, canvW);
        if r1 > canvH || c1 > canvW, continue; end
        idx = randi(size(mosaicPalette,1));
        col = mosaicPalette(idx,:) * (0.85 + rand()*0.30);
        col = min(col, 1);
        for ch = 1:3
            canvas(r1:r2, c1:c2, ch) = col(ch);
        end
        rb1 = min(r2-leadW+1, canvH); rb2 = r2;
        if rb1 >= 1, canvas(rb1:rb2, c1:c2, :) = 0.04; end
        cb1 = min(c2-leadW+1, canvW); cb2 = c2;
        if cb1 >= 1, canvas(r1:r2, cb1:cb2, :) = 0.04; end
    end
end
canvasBg = canvas;
bgBloom = imgaussfilt(canvasBg, 3.0);
canvasBg = min(canvasBg*0.85 + bgBloom*0.20, 1);

artTop = marginY + 1; artBot = marginY + imgH;
artLeft = marginX + 1; artRight = marginX + imgW;
for ch = 1:3
    canvasBg(artTop:artBot, artLeft:artRight, ch) = J_art(:,:,ch);
end

frameCanvas = canvasBg;
blackFrame = [0.04, 0.04, 0.04];
frameGold  = [0.72, 0.58, 0.10];
outerPad = round(min(marginX, marginY) * 0.12);
bW = max(8, round(min(marginX, marginY) * 0.18));
for ch = 1:3
    frameCanvas(:, outerPad:outerPad+bW, ch) = blackFrame(ch);
    frameCanvas(:, canvW-outerPad-bW:canvW-outerPad, ch) = blackFrame(ch);
    frameCanvas(outerPad:outerPad+bW, :, ch) = blackFrame(ch);
    frameCanvas(canvH-outerPad-bW:canvH-outerPad, :, ch) = blackFrame(ch);
end
innerPad = round(min(marginX, marginY) * 0.04);
innerW   = max(5, round(min(marginX, marginY) * 0.10));
leftEdge   = max(artLeft  - innerPad - innerW, 1);
rightEdge  = min(artRight + innerPad + innerW, canvW);
topEdge    = max(artTop   - innerPad - innerW, 1);
bottomEdge = min(artBot   + innerPad + innerW, canvH);
for ch = 1:3
    frameCanvas(topEdge:bottomEdge, leftEdge:artLeft-innerPad, ch) = blackFrame(ch);
    frameCanvas(topEdge:bottomEdge, artRight+innerPad:rightEdge, ch) = blackFrame(ch);
    frameCanvas(topEdge:artTop-innerPad, leftEdge:rightEdge, ch) = blackFrame(ch);
    frameCanvas(artBot+innerPad:bottomEdge, leftEdge:rightEdge, ch) = blackFrame(ch);
end
gW = max(1, round(innerW * 0.18));
for ch = 1:3
    frameCanvas(topEdge:bottomEdge, artLeft-innerPad-gW:artLeft-innerPad, ch) = frameGold(ch);
    frameCanvas(topEdge:bottomEdge, artRight+innerPad:artRight+innerPad+gW, ch) = frameGold(ch);
    frameCanvas(artTop-innerPad-gW:artTop-innerPad, leftEdge:rightEdge, ch) = frameGold(ch);
    frameCanvas(artBot+innerPad:artBot+innerPad+gW, leftEdge:rightEdge, ch) = frameGold(ch);
end

archCx = (artLeft + artRight) / 2;
archW  = (artRight - artLeft) / 2;
archBaseY = artTop - innerPad;
archHeight = round(archW * 0.55);
archTipY   = archBaseY - archHeight;
[XX, YY] = meshgrid(1:canvW, 1:canvH);
lcx = artLeft + round(archW * 0.38); lcy = archBaseY; lr = round(archW * 0.72);
leftLobe = (XX - lcx).^2 + (YY - lcy).^2 <= lr^2;
rcx = artRight - round(archW * 0.38); rcy = archBaseY; rr = round(archW * 0.72);
rightLobe = (XX - rcx).^2 + (YY - rcy).^2 <= rr^2;
archMask = (leftLobe | rightLobe) & (YY <= archBaseY) & (YY >= archTipY);
archBorder = imdilate(archMask, strel('disk', max(3, round(innerW*0.55)))) & ~archMask;
archBorder = archBorder & (YY <= archBaseY);
for ch = 1:3
    p = frameCanvas(:,:,ch); p(archBorder) = blackFrame(ch); frameCanvas(:,:,ch) = p;
end
archGoldBorder = imdilate(archMask, strel('disk', max(1,gW*2))) & ...
                 ~imdilate(archMask, strel('disk', max(1,gW))) & (YY <= archBaseY);
for ch = 1:3
    p = frameCanvas(:,:,ch); p(archGoldBorder) = frameGold(ch); frameCanvas(:,:,ch) = p;
end
ksR = max(4, round(archW * 0.04));
ksMask = (XX - round(archCx)).^2 + (YY - archTipY).^2 <= ksR^2;
for ch = 1:3
    p = frameCanvas(:,:,ch); p(ksMask) = frameGold(ch); frameCanvas(:,:,ch) = p;
end
out = max(0, min(1, frameCanvas));
end
