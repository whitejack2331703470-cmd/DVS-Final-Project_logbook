function out = artify_poster(img, colorBW, nSeeds, edgeStrength, E)
% ARTIFY_POSTER  Style 1: Poster / Pop Art effect.
%   Flat colors, high contrast, strong edges - visually distinct from watercolor.
%
%   Pipeline: Mean-Shift color quant → Contrast stretching (Lab3) → Sobel edge → overlay
%
%   Course connections:
%   - Lab2: RGB color space
%   - Lab3: Contrast stretching s=1/(1+(k/r)^E), edge(Sobel)
%   - Lab5: Mean-Shift color quantization
%
%   Inputs:
%     img          - RGB image (path or matrix)
%     colorBW      - Mean-Shift bandwidth (default 0.08)
%     nSeeds       - Mean-Shift seeds (default 400)
%     edgeStrength - Edge darkness 0-1 (default 0.5)
%     E            - Contrast stretch steepness (default 0.9)

if nargin < 5, E = 0.9; end
if nargin < 4, edgeStrength = 0.5; end
if nargin < 3, nSeeds = 400; end
if nargin < 2, colorBW = 0.08; end

if ischar(img) || isstring(img), img = imread(img); end
if size(img, 3) == 1, img = repmat(img, [1 1 3]); end
img = im2double(img);

%% Stage 1: Mean-Shift color quantization (Lab5 - required)
[quantized, ~] = meanShiftColorQuant(img, colorBW, nSeeds);

%% Stage 2: Contrast stretching (Lab3 Task 2)
% s = 1/(1 + (k/r)^E) - expands midtones, compresses extremes
for c = 1:3
    r = quantized(:, :, c) + eps;
    k = mean2(r);
    s = 1 ./ (1 + (k ./ r) .^ E);
    quantized(:, :, c) = max(0, min(1, s));
end

%% Stage 3: Sobel edge detection (Lab5 Task 2)
gray = rgb2gray(quantized);
edges = edge(gray, 'Sobel', 0.05);

%% Stage 4: Edge overlay (darken at edges for poster effect)
out = quantized;
for c = 1:3
    ch = out(:, :, c);
    ch(edges) = ch(edges) * (1 - edgeStrength);
    out(:, :, c) = ch;
end

out = max(0, min(1, out));

end
