function out = artify_bright_watercolor(img, seSize, beta, edgeGain, wobbleScale)
% ARTIFY_BRIGHT_WATERCOLOR  Bright watercolor effect from lxy project (Patrick Doran style).
%   Uses medfilt3 + imclose for abstraction (no cartoon), pigment density, edge darkening,
%   wobbling, and HSV gamma correction for a lighter, brighter watercolor look.
%
%   Inputs:
%     img        - RGB image (path or matrix)
%     seSize     - Morphological closing disk size (default 8)
%     beta       - Pigment density scaling (default 0.5)
%     edgeGain   - Edge darkening strength (default 0.8)
%     wobbleScale- Paper wobble amplitude (default 3)

if nargin < 5, wobbleScale = 3; end
if nargin < 4, edgeGain = 0.8; end
if nargin < 3, beta = 0.5; end
if nargin < 2, seSize = 8; end

if ischar(img) || isstring(img), img = imread(img); end
if size(img, 3) == 1, img = repmat(img, [1 1 3]); end
img = im2double(img);
if size(img, 3) == 4, img = img(:,:,1:3); end

%% Abstraction: medfilt3 + morphological closing (no cartoon - brighter style)
abstract_img = imclose(medfilt3(img, [7 7 1]), strel('disk', round(seSize)));

[h, w, ~] = size(img);

%% Pigment density variation
rng(42);
T = imgaussfilt(rand(h, w), 2);
d = 1 + beta * (T - 0.5);
watercolor_effect = abstract_img - (abstract_img - abstract_img.^2) .* (d - 1);

%% Edge darkening
gray_img = rgb2gray(abstract_img);
grad = imgradient(gray_img);
grad = grad / (max(grad(:)) + eps);
edge_darken_d = 1 + edgeGain * (grad - 0.2);
for c = 1:3
    watercolor_effect(:,:,c) = watercolor_effect(:,:,c) .* (2 - edge_darken_d);
end

%% Wobbling (paper grain)
[X, Y] = meshgrid(1:w, 1:h);
distort_X = X + (rand(h, w) - 0.5) * wobbleScale;
distort_Y = Y + (rand(h, w) - 0.5) * wobbleScale;
for c = 1:3
    watercolor_effect(:,:,c) = interp2(X, Y, watercolor_effect(:,:,c), distort_X, distort_Y, 'linear', 0);
end
watercolor_effect = imopen(watercolor_effect, strel('disk', 2));

%% HSV gamma correction (brightness - Patrick Doran style)
hsv = rgb2hsv(watercolor_effect);
hsv(:,:,2) = hsv(:,:,2) .^ 0.6;
hsv(:,:,3) = hsv(:,:,3) .^ 0.45;
out = hsv2rgb(hsv);

out = max(0, min(1, out));

end
